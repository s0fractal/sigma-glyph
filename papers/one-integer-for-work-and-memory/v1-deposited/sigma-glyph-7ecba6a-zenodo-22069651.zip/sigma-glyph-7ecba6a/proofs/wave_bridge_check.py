#!/usr/bin/env python3
"""Differential bridge for proofs/WaveAlgebra.lean (Book II wave algebra).

The Lean theorems are about the Lean `interfere`; this bridge is the honest
seam that ties them to the live oracle:

  1. Freshness: proofs/LutData.lean regenerates byte-identically from the
     oracle's arbiter-checked LUT (a stale or hand-edited table fails).
  2. Soundness guard (proof_guard.py, front "wave"): `lean` exits 0 even when
     a proof uses `sorry` (it is a warning) — this bridge runs the source
     layer over LutData/WaveAlgebra/WaveRun (literal-aware comment stripping,
     sorry/admit/axiom, import allowlist, metaprogramming denylist, coverage
     registry) AND a data-only environment query asserting the load-bearing
     theorems stay within the documented TCB (std axioms; native_decide trust
     axioms only where README attributes them to the compiler) and still
     state what proofs/theorem_pins.json pins them to state.
  3. Differential: proofs/WaveRun.lean (the Lean `interfere`, executed) must
     agree with impl/sigma_wave.py `interfere` on a deterministic boundary
     grid plus the pinned special points (crystallization, the
     FV-FOLD-UNSOUND triple, negative-tie parities).

Needs a `lean` binary (elan). Exit 2 if unavailable — never a silent pass.
"""
import itertools, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(REPO, "impl"))
import proof_guard  # noqa: E402
from sigma_wave import interfere, W  # noqa: E402

#: Load-bearing theorems (proofs/README.md, Book II section) and — per its
#: TCB-honesty paragraph — which of them may rest on native_decide: both
#: lists, plus the pinned statements, live in theorem_pins.json.
FRONT = proof_guard.load_front("wave")
THEOREMS = FRONT["guarded"]


def fail(msg):
    print("FAIL  " + msg)
    sys.exit(1)


def check_lut_freshness():
    with tempfile.TemporaryDirectory() as td:
        with open(os.path.join(HERE, "LutData.lean"), "rb") as source:
            cur = source.read()
        tmp_out = os.path.join(td, "LutData.lean")
        r = subprocess.run([sys.executable, os.path.join(HERE, "gen_lut_lean.py")],
                           capture_output=True, text=True,
                           env=dict(os.environ, LUT_LEAN_OUT=tmp_out))
        if r.returncode != 0:
            fail("LUT regeneration errored: " + r.stderr.strip())
        with open(tmp_out, "rb") as generated:
            fresh = generated.read() == cur
        if not fresh:
            fail("LutData.lean is stale — regenerate with proofs/gen_lut_lean.py")
    print("OK    LutData.lean regenerates byte-identically (arbiter-checked)")


def guard_wave_sources():
    problems = proof_guard.guard_sources(FRONT)
    if problems:
        fail("source guard: " + "; ".join(problems))
    print("OK    LutData + WaveAlgebra + WaveRun pass the source guard (no "
          "sorry/admit/axiom, no metaprogramming, imports in-set, every "
          "theorem accounted for)")


def wave_cases():
    phs = [0, 1, 8192, 16384, 32767, 32768, 49152, 65535]
    ams = [0, 1, 2, 32768, 65534, 65535]
    ens = [-32768, -32767, -1, 0, 1, 32767]
    waves = [W(p, a, e) for p, a, e in itertools.product(phs, ams, ens)]
    cases = []
    for i, w in enumerate(waves):
        cases.append((w, w))                                  # self (crystallization line)
        cases.append((w, waves[(i * 7 + 3) % len(waves)]))    # deterministic partner
    for tri in [(W(0, 65535, 0), W(16384, 65535, 0), W(16384, 65535, 0))]:
        w1, w2, w3 = tri                                      # FV-FOLD-UNSOUND
        cases += [(w1, w2), (w2, w3), (interfere(w1, w2), w3),
                  (w1, interfere(w2, w3))]
    cases.append((W(0, 65535, -32768), W(0, 65535, -32768)))  # crystal point
    cases.append((W(0, 100, -1), W(0, 100, -2)))              # negative tie (WV-NEG-TIE class)
    return cases


def run_lean_wave(lean, cases):
    lines = "".join(f"{a['ph']} {a['am']} {a['en']} {b['ph']} {b['am']} {b['en']}\n"
                    for a, b in cases)
    with tempfile.TemporaryDirectory() as td:
        env = dict(os.environ, LEAN_PATH=td)
        # FRONT["build"] is the single place this front's compiled module set
        # is spelled — the guard reads the same field, so the two cannot drift
        # apart (round-4 F17).
        err = proof_guard.build_front(lean, FRONT, td)
        if err:
            fail(err)
        print("OK    LutData + WaveAlgebra compile clean (theorems check)")
        err = proof_guard.guard_semantics(lean, FRONT, td)
        if err:
            fail(err)
        print(f"OK    axiom cones clean, statements match their pins AND every "
              f"definition they are stated in terms of matches its pin "
              f"(`Valid`, `interfere`, the LUT), for {len(THEOREMS)} wave "
              "theorems (std axioms; native_decide only where the TCB says so)")
        r = subprocess.run([lean, "--run", os.path.join(HERE, "WaveRun.lean")],
                           input=lines, capture_output=True, text=True, env=env)
    if r.returncode != 0:
        fail("WaveRun.lean failed: " + (r.stderr or r.stdout).strip()[:500])
    return r.stdout.strip().splitlines()


def compare_wave_cases(cases, got):
    if len(got) != len(cases):
        fail(f"WaveRun emitted {len(got)} lines for {len(cases)} cases")
    bad = 0
    for (a, b), line in zip(cases, got):
        exp = interfere(a, b)
        want = f"{exp['ph']} {exp['am']} {exp['en']}"
        if line.strip() != want:
            bad += 1
            if bad <= 5:
                print(f"DISAGREE  {a} · {b}: lean={line.strip()!r} oracle={want!r}")
    if bad:
        fail(f"{bad}/{len(cases)} disagreements between Lean and the oracle")


def main():
    lean = proof_guard.find_lean()
    if lean is None:
        print("wave bridge needs a `lean` binary (elan) — set LEAN=... ; exit 2")
        return 2
    check_lut_freshness()
    guard_wave_sources()
    cases = wave_cases()
    compare_wave_cases(cases, run_lean_wave(lean, cases))
    print(f"OK    Lean interfere == oracle interfere on {len(cases)} boundary cases")
    print(f"\nWAVE-BRIDGE: ALL AGREE ({len(cases)}/{len(cases)})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
