#!/bin/sh
# ai-review.sh — run an external AI reviewer over a DISPOSABLE clone of this repo.
#
#   tools/ai-review.sh agy        2026-07-gemini-adr-gate.md  "focus text..."
#   tools/ai-review.sh codex      2026-07-codex-foo.md        "focus text..."
#   tools/ai-review.sh openrouter 2026-07-<model>-foo.md      "focus text..."
#     (openrouter needs OPENROUTER_MODEL + a funded key; the model cannot run
#      code, so tools/or_review.py ships gate transcripts in a briefing pack
#      and uses a two-pass blind protocol; runs against the live repo READ-ONLY)
#
# The reviewer works in a throwaway clone (never the live checkout); the ONLY
# artifact copied back is reviews/<outfile>. The maintainer then verifies the
# review's claims independently and adjudicates (response doc + warrant).
# Model override: AGY_MODEL env (default "Gemini 3.1 Pro (High)").
set -eu
CLI=${1:?usage: ai-review.sh <agy|codex|openrouter> <outfile.md> [focus...]}
OUT=${2:?missing output review filename}
shift 2
FOCUS=${*:-"Full adversarial spec review."}

# OpenRouter backend: no clone needed — or_review.py only reads sources and
# writes reviews/$OUT; the model never gets filesystem access at all.
if [ "$CLI" = "openrouter" ]; then
    exec python3 "$(dirname "$0")/or_review.py" "$OUT" "$FOCUS"
fi
REPO=$(git rev-parse --show-toplevel)
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
git clone -q "$REPO" "$T/repo"
cd "$T/repo"
# Isolation: the origin remote points at the live checkout; a reviewer with
# broad permissions has been observed following it and writing to the live
# repo directly. Remove the breadcrumb and pin the reviewer to this directory.
git remote remove origin
LIVE_STATE=$(git -C "$REPO" status --porcelain)

PROMPT="You are an independent adversarial reviewer of this repository.

PROTOCOL (binding): read reviews/README.md first. Run first, read second:
  python3 impl/sigma_glyph.py                       # must print ALL PASS
  python3 impl/sigma_wave.py                        # must print WAVE: ALL PASS
  python3 impl/sigma_federation.py                  # must print FEDERATION: ALL PASS
  python3 tests/spec_conformance/run_reference.py   # must print ALL PASS
  python3 tools/verify_anchors.py                   # must verify
Include a verified-vectors statement with the actual outputs you saw.

FOCUS: $FOCUS

RULES:
- Severity ladder P0/P1/P2/P3 per reviews/README.md. Settled points are listed
  there; re-litigation requires genuinely new evidence.
- Form your own findings from the primary texts BEFORE reading prior reviews in
  reviews/; then add a section stating where you agree, disagree, and what is
  new relative to them.
- Every claim that can be checked by running code: check it by running code,
  and show the command.
- Give concrete text proposals for every P1/P2.
- Write the COMPLETE review to reviews/$OUT and nothing else: do not modify any
  other file, do not commit, do not push.
- Work ONLY inside the current working directory ($T/repo). Never touch any
  other checkout of this project, even if you know one exists.
"

case "$CLI" in
  agy)
    agy --add-dir . --dangerously-skip-permissions \
        --model "${AGY_MODEL:-Gemini 3.1 Pro (High)}" \
        --print-timeout 45m -p "$PROMPT"
    ;;
  codex)
    # </dev/null: codex exec reads extra prompt text from stdin when it is not
    # a TTY and blocks until EOF — fatal for background runs that keep stdin open
    codex exec --sandbox workspace-write "$PROMPT" </dev/null
    ;;
  *)
    echo "unknown reviewer CLI: $CLI" >&2; exit 2
    ;;
esac

TAINTED=0
if [ "$(git -C "$REPO" status --porcelain)" != "$LIVE_STATE" ]; then
    echo "WARNING: live checkout changed during review — inspect git status before trusting it" >&2
    TAINTED=1
fi
test -s "reviews/$OUT" || { echo "reviewer did not write reviews/$OUT" >&2; exit 1; }
cp "reviews/$OUT" "$REPO/reviews/$OUT"
echo "review delivered: reviews/$OUT"
# The review IS delivered above — the isolation breach does not invalidate the
# text, it invalidates the claim that the reviewer stayed in its clone. Printing
# that to stderr and then exiting 0 is the "silent exit 0" class: a caller that
# checks $? (the normal thing, and what any wrapper does) was told the run was
# clean. It was not.
[ "$TAINTED" = 0 ] || exit 1
